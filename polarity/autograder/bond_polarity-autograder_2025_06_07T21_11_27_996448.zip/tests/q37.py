OK_FORMAT = True

test = {   'name': 'q37',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> glycine.GetNumAtoms() == 10\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumBonds() == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(glycine) == rdkit.Chem.rdchem.RWMol\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> carbon2 == 4 and hydrogen2 == 5 and (hydrogen3 == 6) and (hydrogen4 == 7) and (hydrogen5 == 8) and (oxygen2 == 9)\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
