OK_FORMAT = True

test = {   'name': 'q21',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(hydrogen1) == rdkit.Chem.rdchem.Atom\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(hydrogen2) == rdkit.Chem.rdchem.Atom\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> hydrogen2_index == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> hydrogen1_index == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(h2o_molecule) == rdkit.Chem.rdchem.RWMol\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> h2o_molecule.GetNumAtoms() == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> h2o_molecule.GetNumBonds() == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
