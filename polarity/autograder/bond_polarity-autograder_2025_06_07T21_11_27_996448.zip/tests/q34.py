OK_FORMAT = True

test = {   'name': 'q34',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 28 * (en_diff_N_H * 0.12 - 43)\n-1200.976', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(en_diff_C_H) == float and en_diff_C_H * 7 - 90 == -87.2 and (en_diff_C_H >= 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(en_diff_C_O) == float and en_diff_C_O * 7 - 90 == -83.0 and (en_diff_C_H >= 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(en_diff_N_H) == float and 28 * (en_diff_N_H * 0.12 - 43) == -1200.976 and (en_diff_N_H > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(en_diff_C_N) == float and -9 * (en_diff_C_N * 0.34 - 9) == 79.47 and (en_diff_C_N > 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
