OK_FORMAT = True

test = {   'name': 'q35',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> answer * 16 ** 0.5 / 24 == 2 / 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(answer) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> answer > 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
