OK_FORMAT = True

test = {   'name': 'q312',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> soluble + 2.3 / 0.9 - 1 + 9.8 / 3.2 - 0.5 * 2 == 4.618055555555555\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
