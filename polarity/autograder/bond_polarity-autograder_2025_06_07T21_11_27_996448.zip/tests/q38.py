OK_FORMAT = True

test = {   'name': 'q38',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> glycine.GetNumAtoms() == 10\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumBonds() == 9\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumHeavyAtoms() == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumConformers() == 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
