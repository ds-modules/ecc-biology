OK_FORMAT = True

test = {   'name': 'q32',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(Mg_Cl) == float and Mg_Cl * 7 - 90 == -77.4 and (Mg_Cl > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(Ti_O) == float and 5 * (Ti_O * 28 - 90) == -170.0 and (Ti_O > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(S_F) == float and 28 * (S_F * 0.12 - 43) == -1198.96 and (S_F > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(N_O) == float and -9 * (N_O * 0.34 - 9) == 79.47 and (N_O > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(C_S) == float and -34 * C_S ** 0.5 == 0 and (C_S >= 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(Cl_O) == float and Cl_O * 0.5 + 1 == 1.25 and (Cl_O > 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
