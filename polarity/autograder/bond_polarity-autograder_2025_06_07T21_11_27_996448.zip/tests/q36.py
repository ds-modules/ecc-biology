OK_FORMAT = True

test = {   'name': 'q36',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(glycine) == rdkit.Chem.rdchem.RWMol\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumAtoms() == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> glycine.GetNumBonds() == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> carbon == 0 and hydrogen == 1 and (oxygen == 2) and (nitrogen == 3)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(carbon) == int and type(hydrogen) == int and (type(oxygen) == int) and (type(nitrogen) == int)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
