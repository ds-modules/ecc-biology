OK_FORMAT = True

test = {   'name': 'q31',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> gold_EN * 3 / 8 - 25 == -24.1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(gold_EN) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> gold_EN > 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
